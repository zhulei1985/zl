(function () {
    'use strict';

    class SyncBaseAttribute
    {

    }

    class SyncIntAttribute extends SyncBaseAttribute
    {
        DecodeData4Bytes(data)
        {
            console.log("SyncIntAttribute DecodeData4Bytes");
            this.val = data.getInt32();
        }
    }

    class SyncStringAttribute extends SyncBaseAttribute
    {
        DecodeData4Bytes(data)
        {
            console.log("SyncStringAttribute DecodeData4Bytes");
            var len = data.getInt32();
            this.val = "";
            for (var i = 0; i < len; i++)
            {
                this.val += String.fromCharCode(data.getByte());
            }
        }
    }

    class SyncBaseClass
    {
        constructor()
        {
            if (SyncBaseClass.IndexCount == undefined)
            {
                SyncBaseClass.IndexCount = 0;
            }
            SyncBaseClass.IndexCount++;
            this.index = SyncBaseClass.IndexCount;

            this.Parm = [];
            this.Parm4Name = {};
            this.UpSync = {};
            this.DownSync = [];
            this.syncConnects = {};
            this.rootserverID = 0;
            this.rootIndex = 0;
        }

        INIT_SYNC_ATTRIBUTE(index,type,name)
        {
            var val = new type;
            if (val instanceof SyncBaseAttribute)
            {
                this.Parm[index] = val;
                this.Parm4Name[name] = val;
            }
        }
        SetAttribute(name,val)
        {
            var attr = this.Parm4Name[name];
            if (attr)
            {
                attr.val = val;
            }
        }
        GetAttribute(name)
        {
            var attr = this.Parm4Name[name];
            if (attr)
            {
                return attr.val;
            }
            return undefined;
        }

        GetIndex()
        {
            return this.index;
        }

        DecodeData4Bytes(data)
        {
            var size = data.getInt16();
            console.log("DecodeData4Bytes:"+size);        
            for (var i = 0; i < size; i++)
            {
                var index = data.getInt16();
                var attr =  this.Parm[index];
                if (attr)
                {
                    attr.DecodeData4Bytes(data);
                }
            }
        }

        AddUnSync(id, tier)
        {
            this.UpSync[id] = tier;
        }
        AddSync(id)
        {
            if (this.syncConnects[id] == null)
            {
                this.syncConnects[id] = 1;
            }
        }
        CheckSync(id)
        {
            if (this.syncConnects[id] != null)
            {
                return true;
            }
            return false;
        }
    }

    //export { SyncIntAttribute, SyncStringAttribute, SyncBaseClass };

    class SyncClassCache
    {
        constructor()
        {
            this.mapClassType = {};
            this.mapClassPoint = {};

            this.mapServerID = {};
        }
        RegisterClassType(classname, classtype)
        {
            this.mapClassType[classname] = classtype;
        }
        NewClass(classname)
        {
            var classType = this.mapClassType[classname];
            if (classType != undefined)
            {
                var point = new classType();
                this.mapClassPoint[point.GetIndex()] = point;
                point.ClassName = classname;
                return point;
            }
            return null;
        }
        GetClass(index)
        {
            var point = this.mapClassPoint[index];
           // if ()
           return point;
        }

        GetSyncIndex(serverID, rootIndex)
        {
            if (this.mapServerID[serverID] != undefined)
            {
                var server = this.mapServerID[serverID];
                return server[rootIndex];
            }
            return undefined;
        }
        SetSyncIndex(serverID, rootIndex, curIndex)
        {
            if (this.mapServerID[serverID] == undefined)
            {
                this.mapServerID[serverID] = {};
            }
            var server = this.mapServerID[serverID];
            server[rootIndex] = curIndex;
        }
    }

    var cache = new SyncClassCache();

    class CNetWorkFunMgr
    {
        constructor()
        {
            this.FunCache = {};
        }
        RegisterFun(name, point,Fun)
        {
            var call = Laya.Handler.create(point,Fun,null,false);
            this.FunCache[name] = call;
            //call.runWith()
        }
        GetFun(name)
        {
            return this.FunCache[name];
        }
        run(name,data)
        {
            var call = this.FunCache[name];
            if (call)
            {
                call.runWith(data);
            }
        }
    }

    var maker = new CNetWorkFunMgr();

    //这个文件用于与服务器网络网络连接部分的接口
    function HashMap(){
        this.map = {};
    }
    HashMap.prototype = {
        put : function(key,value){
            this.map[key] = value;
        },
        get : function(key)
        {
            if (this.map.hasOwnProperty(key))
            {
                return this.map[key];
            }
            return null;
        },
        remove : function(key)
        {
            if (this.map.hasOwnProperty(key))
            {
                return delete this.map[key];
            }
            return false;
        },
        removeAll : function()
        {

        },
        keySet : function()
        {
            var _keys = [];
            for (var i in this.map)
            {
                _keys.push(i);
            }
            return _keys;
        }
    };
    class Connector
    {
        constructor(ip, port)
        {
            if (Connector.connectID == undefined)
            {
                Connector.connectID = 1;
            }
            this.Recvbyte = new Laya.Byte();
            this.Recvbyte.endian = Laya.Byte.BIG_ENDIAN;
            this.connectID = Connector.connectID++;
            this.mapClassIndex2Image = {};
            this.mapClassImage2Index = {};
            this.classImageIndexCount = 0;


            this.hasConnect = false;
            this.socket = new Laya.Socket();//创建 socket 对象

            this.socket.on(Laya.Event.OPEN, this, this.openHandler);//连接正常打开抛出的事件
            this.socket.on(Laya.Event.MESSAGE, this, this.receiveHandler);//接收到消息抛出的事件
            this.socket.on(Laya.Event.CLOSE, this, this.closeHandler);//socket关闭抛出的事件
            this.socket.on(Laya.Event.ERROR, this, this.errorHandler);//连接出错抛出的事件
            this.socket.connect(ip, port);

            this.E_RUN_SCRIPT = 64;
    	    this.E_RUN_SCRIPT_RETURN = 65;
            this.E_SYNC_CLASS_INFO = 66;//同步类的状态
            this.E_SYNC_CLASS_DATA = 67;//同步类数据
            
    	    this.E_SYNC_DOWN_PASSAGE = 68;//下行同步通道
            this.E_SYNC_UP_PASSAGE = 69;//上行同步通道
        
            this.EScriptVal_Int = 1;
    		this.EScriptVal_Double = 2;
    		this.EScriptVal_String = 3;
    		this.EScriptVal_ClassPointIndex = 4;
            //this.RecvFunMap = new Map([this.E_RUN_SCRIPT,this.Recv_RunScript],
            //                            [this.E_RUN_SCRIPT_RETURN,this.Recv_ScriptReturn],
            //                            [this.E_SYNC_CLASS_INFO,this.Recv_SyncClassInfo],
            //                            [this.E_SYNC_CLASS_DATA,this.Recv_SyncClassData]);

            this.RpcFun = new HashMap();
            this.RpcIDAssign = 0;
        }
        GetImage4Index(index)
        {
            if (this.mapClassIndex2Image[index] != undefined)
            {
                return this.mapClassIndex2Image[index];
            }
            return 0;
        }
        GetIndex4Image(index)
        {
            if (this.mapClassImage2Index[index] != undefined)
            {
                return this.mapClassImage2Index[index];
            }
            return 0;
        }
        SetImageAndIndex(imageIndex, loaclIndex)
        {
            this.mapClassIndex2Image[loaclIndex] = imageIndex;
            this.mapClassImage2Index[imageIndex] = loaclIndex;
        }


        openHandler(event){

            console.log("连接服务器成功.");

            //往服务器发送数据
            this.hasConnect = true;
        }

        //接收到服务器数据时触发

        receiveHandler(msg){

            console.log("收到服务器消息：");
            console.log(msg);
            this.Recvbyte.clear();
            this.Recvbyte.writeArrayBuffer(msg);//把接收到的二进制数据读进byte数组便于解析。
            this.Recvbyte.pos = 0;//设置偏移指针
            
            var type = this.Recvbyte.getByte();
            console.log("消息类型："+type);
            var msg;
            switch (type)
            {
            case this.E_RUN_SCRIPT:
                msg = this.Recv_RunScript();
                break;
    	    case this.E_RUN_SCRIPT_RETURN:
                msg = this.Recv_ScriptReturn();
                break;
            case this.E_SYNC_CLASS_INFO://同步类的状态
                msg = this.Recv_SyncClassInfo();
                break;
            case this.E_SYNC_CLASS_DATA://同步类数据
                msg = this.Recv_SyncClassData();
                break;
            case this.E_SYNC_DOWN_PASSAGE://下行同步通道
                break;
            case this.E_SYNC_UP_PASSAGE://上行同步通道
                break;
            }
            console.log(msg);
        }
        

        //与服务器连接关闭时触发

        closeHandler(e){

            console.log("与服务器连接断开.");

        }

        //与服务器通信错误时触发

        errorHandler(e){

            console.log("与服务器通信错误.");
        }
        // int64BEtoNumber(bytes) {
        //     let sign = bytes[0] >> 7;
        //     let sum = 0;
        //     let digits = 1;
        //     for (let i = 0; i < 8; i++) {
        //       let value = bytes[7 - i];
        //       sum += (sign ? value ^ 0xFF : value) * digits;
        //       digits *= 0x100;
        //     }
        //     return sign ? -1 - sum : sum;
        // }
           
        // numberToInt64BE(number) {
        //     let result = [];
        //     let sign = number < 0;
        //     if (sign) number = -1 - number;
        //     for (let i = 0; i < 8; i++) {
        //       let mod = number % 0x100;
        //       number = (number - mod) / 0x100;
        //       result[7 - i] = sign ? mod ^ 0xFF : mod;
        //     }
        //     return result;
        // }
        GetInt64(data)
        {
            let byteVal = data.getByte();
            let sign = byteVal >> 7;
            let sum = byteVal;
            let digits = 1;
            for (let i = 0; i < 7; i++) {
                let value = data.getByte();
                sum *= 0x100;
                sum += (sign ? value ^ 0xFF : value);
            }
            return sign ? -1 - sum : sum;
        }
        AddInt64(data,val)
        {
            let sign = val < 0;
            if (sign) val = -1 - val;
            let result = [];
            for (let i = 0; i < 8; i++) {
                let mod = val % 0x100;
                val = (val - mod) / 0x100;
                result[7 - i]  = sign ? mod ^ 0xFF : mod;
            }
            for (let i = 0; i < 8; i++) {
                data.writeByte(result[i]);
            }
        }
        GetString(data)
        {
            var len = data.getInt32();
            var str = "";
            for (var i = 0; i < len; i++)
            {
                str += String.fromCharCode(data.getByte());
            }
            console.log("GetString,len:"+str.length+",val="+str);
            return str;
        }
        AddString(data, str)
        {
            //console.log("AddString,len:"+str.length);
            data.writeInt32(str.length);
            //data.writeUTFBytes(str);
            for (var i = 0; i < str.length; i++)
            {
                //console.log(str.charCodeAt(i));
                data.writeByte(str.charCodeAt(i));
            }
        }

        Recv_RunScript()
        {
            console.log("Recv_RunScript,begin:");
            var data = this.Recvbyte;
            var msg = {};
            msg.RPC_ID = this.GetInt64(data);
            msg.strFunName = this.GetString(data);
            console.log("函数名字:"+msg.strFunName);
            var parmNum = data.getByte();
            console.log("参数数量:"+parmNum);
            msg.parm = [];
            for (var i = 0; i < parmNum; i++)
            {
                var parm;
                var parmType = data.getByte();
                console.log("参数:"+i+",类型"+parmType);
                if (parmType == this.EScriptVal_Int)
                {
                    parm = this.GetInt64(data);
                }
                else if (parmType == this.EScriptVal_Double)
                {
                    parm = data.getFloat64();
                }
                else if (parmType == this.EScriptVal_String)
                {
                    parm = this.GetString(data);
                }
                else if (parmType == this.EScriptVal_ClassPointIndex)
                {
                    var classname = this.GetString(data);
                    var classtype = data.getByte();
                    var classindex = this.GetInt64(data);
                    console.log("class name="+classname+",type="+classtype+",index="+classindex);
                    if (classtype == 0)
                    {
                        parm = cache.GetClass(classindex);
                    }
                    else
                    {
                        var Index = this.GetIndex4Image(classindex);
                        parm = cache.GetClass(Index);
                    }
                    console.log(parm);
                }
                msg.parm.push(parm);
            }
            var returnVal = 0;
            var Fun = maker.GetFun(msg.strFunName);
            if (Fun)
            {
                returnVal = Fun.runWith(msg.parm);            
            }

            if (msg.RPC_ID > 0)
            {
                //返回
                Send_Return(msg.RPC_ID,returnVal);
            }
            console.log("Recv_RunScript,end:");
            return msg;
        }
        Recv_ScriptReturn()
        {
            var data = this.Recvbyte;
            var msg = {};
            msg.RPC_ID = this.GetInt64(data);
            var parmNum = data.getByte();
            msg.parm = [];
            for (var i = 0; i < parmNum; i++)
            {
                var parm = 0;
                var parmType = data.getByte();
                if (parmType == this.EScriptVal_Int)
                {
                    parm = this.GetInt64(data);
                }
                else if (parmType == this.EScriptVal_Double)
                {
                    parm = data.getFloat64();
                }
                else if (parmType == this.EScriptVal_String)
                {
                    parm = this.GetString(data);
                }
                else if (parmType == this.EScriptVal_ClassPointIndex)
                {
                    var classname = this.GetString(data);
                    var classtype = data.getByte();
                    var classindex = this.GetInt64(data);
                    if (classtype == 0)
                    {
                        parm = cache.GetClass(classindex);
                    }
                    else
                    {
                        var Index = this.GetIndex4Image(classindex);
                        parm = cache.GetClass(Index);
                    }
                }
                msg.parm.push(parm);
            }
            if (msg.RPC_ID > 0)
            {
                var fun = this.RpcFun[msg.RPC_ID];
                if (fun != undefined)
                {
                    fun.runWith(msg.parm);
                }
            }
            return msg;
        }
        Recv_SyncClassInfo()
        {
            console.log("Recv_SyncClassInfo,begin:");
            //上行通道传来同步类数据
            var data = this.Recvbyte;
            var msg = {};
            msg.nClassID = this.GetInt64(data);
            msg.strClassName = this.GetString(data);
            msg.nRootServerID = data.getInt32();
            msg.nRootClassID = this.GetInt64(data);
            msg.nTier = data.getInt32();

            msg.classPoint = null;
            var Index = this.GetIndex4Image(msg.nClassID);
            if (Index != 0)
            {
                msg.classPoint = cache.GetClass(Index);
            }
            if (msg.classPoint == null)
            {
                Index = cache.GetSyncIndex(msg.nRootServerID, msg.nRootClassID);
                if (Index != 0)
                {
                    msg.classPoint = cache.GetClass(Index);
                }
                if (msg.classPoint == null)
                {
                    msg.classPoint = cache.NewClass(msg.strClassName);
     
                    if (msg.classPoint != null)
                    {
                        this.SetImageAndIndex(msg.nClassID,msg.classPoint.GetIndex());
                        msg.classPoint.connectID = data.connectID;
                        msg.classPoint.syncID = msg.nClassID;
                        msg.classPoint.nRootServerID = msg.nRootServerID;
                        msg.classPoint.nRootClassID = msg.nRootClassID;
                        msg.classPoint.AddUnSync(this.connectID,msg.nTier);
                        cache.SetSyncIndex(msg.nRootServerID, msg.nRootClassID,msg.classPoint.GetIndex());
                    }
                }
            }
            console.log(msg.classPoint);        
            var datalen = data.getInt32();
            if (msg.classPoint != null)
            {
                if ( msg.classPoint.DecodeData4Bytes instanceof Function ){
                    msg.classPoint.DecodeData4Bytes(this.Recvbyte);
                }
            }
            console.log("Recv_SyncClassInfo,end:");
            return msg;
        }

        Recv_SyncClassData()
        {
            console.log("Recv_SyncClassData,begin:");
            var data = this.Recvbyte;
            var msg = {};
            msg.nClassID = this.GetInt64(data);
            var Index = this.GetIndex4Image(msg.nClassID);
            if (Index != 0)
            {
                msg.classPoint = cache.GetClass(Index);
            }
            if (msg.classPoint == null)
            {
                Index = cache.GetSyncIndex(msg.nRootServerID, msg.nRootClassID);
                if (Index != 0)
                {
                    msg.classPoint = cache.GetClass(Index);
                }
            }
            console.log(msg.classPoint);
            var datalen = data.getInt32();
            if (msg.classPoint != null)
            {
                if ( msg.classPoint.DecodeData4Bytes instanceof Function ){
                    msg.classPoint.DecodeData4Bytes(this.Recvbyte);
                }
            }
            console.log("Recv_SyncClassData,end:");
            return msg;
        }

        AddParm2Data(byte,parm)
        {
            if (typeof(parm) == 'number')
            {
                byte.writeByte(this.EScriptVal_Double);
                byte.writeFloat64(parm);
            }
            else if (typeof(parm) == 'string')
            {
                byte.writeByte(this.EScriptVal_String);
                this.AddString(byte,parm);
            }
            else if (typeof(parm) == 'object')
            {
                byte.writeByte(this.EScriptVal_ClassPointIndex);
                this.AddString(byte,parm.strClassName);
                if (parm.connectID == undefined || parm.connectID != this.connectID)
                {
                    if (!parm.CheckSync(this.connectID))
                    {
                        parm.AddSync(this.connectID);
                        this.Send_SyncClassInfo(this,parm);
                    }
                    //this.Send_SyncClassInfo(this,parm);
                    byte.writeByte(1);
                    this.AddInt64(parm.GetIndex());

                }
                else{
                    //这个连接是此类的上行通道
                    byte.writeByte(0);
                    this.AddInt64(this.GetImage4Index(parm.GetIndex()));
                }
                
            }
        }
        Send_RunScript(msg,handler)
        {
            var byte = new Laya.Byte();
            byte.endian = Laya.Byte.BIG_ENDIAN;
            byte.writeByte(this.E_RUN_SCRIPT);
            //this.RpcIDAssign++;
            this.RpcFun[msg.RPC_ID] = handler;
            this.AddInt64(byte,msg.RPC_ID);
            this.AddString(byte,msg.strFunName);
            byte.writeByte(msg.parm.length);
            for (var i = 0; i < msg.parm.length; i++)
            {
                this.AddParm2Data(byte,msg.parm[i]);
            }
            console.log("send run script msg:");
            console.log(byte);
            this.socket.send(byte.buffer);
        }

        Send_Return(returnID, retrunVal)
        {
            var byte = new Laya.Byte();
            byte.endian = Laya.Byte.BIG_ENDIAN;
            byte.writeByte(this.E_RUN_SCRIPT_RETURN);
            this.AddInt64(returnID);
            this.AddParm2Data(byte,retrunVal);

            //this.byte.writeArrayBuffer(retrunVal.toBuffer());
            this.socket.send(byte.buffer);
        }
        //Send_SyncClassInfo(obj)
        //{
        //    //向下行通道发送类数据
        //    var byte = new Laya.Byte();
        //    byte.endian = Laya.Byte.BIG_ENDIAN;
        //    byte.writeByte(this.E_SYNC_CLASS_INFO);
        //    this.AddInt64(obj.GetIndex());
        //    this.AddString(byte,obj.ClassName);
        //    byte.writeInt32(obj.rootserverID);
        //    
        //    this.socket.send(byte.buffer);
        //}
    }

    class CAccount extends SyncBaseClass
    {
        constructor()
        {
            super();

            super.INIT_SYNC_ATTRIBUTE(1,SyncStringAttribute, "nickName");
            super.INIT_SYNC_ATTRIBUTE(2,SyncStringAttribute, "AccName");
        }

    }

    class TalkListItem extends fgui.GButton {
        constructor() {
            super();
        }
    }

    /**
     * 本示例采用非脚本的方式实现，而使用继承页面基类，实现页面逻辑。在IDE里面设置场景的Runtime属性即可和场景进行关联
     * 相比脚本方式，继承式页面类，可以直接使用页面定义的属性（通过IDE内var属性定义），比如this.tipLbll，this.scoreLbl，具有代码提示效果
     * 建议：如果是页面级的逻辑，需要频繁访问页面内多个元素，使用继承式写法，如果是独立小模块，功能单一，建议用脚本方式实现，比如子弹脚本。
     */

    class GameUI extends Laya.Scene {
        constructor() {
            super();
            //加载场景文件
            this.loadScene("test/TestScene.scene");

            var aaa = Laya.Scene3D;
            //添加3D场景
            var scene = Laya.stage.addChild(new aaa());

            //添加照相机
            var camera = (scene.addChild(new Laya.Camera(0, 0.1, 100)));
            camera.transform.translate(new Laya.Vector3(0, 3, 3));
            camera.transform.rotate(new Laya.Vector3(-30, 0, 0), true, false);

            //添加方向光
            var directionLight = scene.addChild(new Laya.DirectionLight());
            directionLight.color = new Laya.Vector3(0.6, 0.6, 0.6);
            directionLight.transform.worldMatrix.setForward(new Laya.Vector3(1, -1, 0));

            //添加自定义模型
            var box = scene.addChild(new Laya.MeshSprite3D(Laya.PrimitiveMesh.createBox(1, 1, 1)));
            box.transform.rotate(new Laya.Vector3(0, 45, 0), false, false);
            var material = new Laya.BlinnPhongMaterial();
    		Laya.Texture2D.load("res/layabox.png", Laya.Handler.create(null, function(tex) {
    				material.albedoTexture = tex;
    		}));
            box.meshRenderer.material = material;
            this.dataList = [];
            fairygui.UIConfig.packageFileExtension = "bin";
            //Laya.stage.addChild(fairygui.GRoot.inst.displayObject);
       
            fgui.UIPackage.loadPackage('res/LoginPackage',new Laya.Handler(this,this.AddUIPackageRes));
            //aya.loader.load({type:Laya.Loader.BUFFER,url:'res/LoginPackage.bin'},Laya.Handler.create(this, ()=>this.AddUIPackageRes()));

            maker.RegisterFun("LoginFail",this,this.LoginFail);
            maker.RegisterFun("LoginSuccess",this,this.LoginSuccess);
            maker.RegisterFun("SendMessage",this,this.SendMessage);

            cache.RegisterClassType("CAccount",CAccount);
            
            this.Connect = new Connector('127.0.0.1',9999);
        }

        AddUIPackageRes()
        {
            fgui.UIObjectFactory.setExtension("ui://LoginPackage/TalkListItem", TalkListItem);
            if (fairygui.UIPackage.getById("res/LoginPackage") != null)
            {
                console.log("资源包已加载");
            }
            fairygui.UIPackage.addPackage('res/LoginPackage');
            Laya.stage.addChild(fairygui.GRoot.inst.displayObject);
            this.LoginUI = fairygui.UIPackage.createObject('LoginPackage','LoginUI');
            this.LoginUI.OnClose = function()
            {
                fgui.GRoot.inst.removeChild(this);
                if(this.destroy)
                    this.destroy();
            };
            fairygui.GRoot.inst.addChild(this.LoginUI);
            var button = this.LoginUI.getChild("n5");
            button.onClick(this,this.LoginAccount);
        }
        OpenRegisterUI()
        {
            var RegisterUI = fairygui.UIPackage.createObject('LoginPackage','RegisterUI');
            RegisterUI.Connect = this.Connect;
            RegisterUI.OnClose = function()
            {
                fgui.GRoot.inst.removeChild(this);
                if(this.destroy)
                    this.destroy();
            };
            fairygui.GRoot.inst.addChild(RegisterUI);
            RegisterUI.LoginResult = function(nResult)
            {
                console.log("RegisterUI LoginResult:"+nResult);
                if (nResult == 0)
                {
                    //注册成功
                    this.OnClose();
                }
            };
            RegisterUI.RegisterAccount = function()
            {
                var account = this.getChild("AccInput");
                var password  = this.getChild("PwInput");
                var msg = {};
                this.Connect.RpcIDAssign++;
                msg.RPC_ID = this.Connect.RpcIDAssign;
                msg.strFunName = "RegisterAccount";
                msg.parm = [account.getChild("n3").text,password.getChild("n3").text];
                console.log("RegisterAccount:");
                console.log(msg);
                this.Connect.Send_RunScript(msg,Laya.Handler.create(this,this.LoginResult));
            };
            var button = RegisterUI.getChild("Submit");
            button.onClick(RegisterUI,RegisterUI.RegisterAccount);
        }
        OpenMainUI()
        {
            var MainUI = fairygui.UIPackage.createObject('LoginPackage','MainUI');
            MainUI.Connect = this.Connect;
            fairygui.GRoot.inst.addChild(MainUI);
            console.log(MainUI);
            MainUI.OnClose = function()
            {
                fgui.GRoot.inst.removeChild(this);
                if(this.destroy)
                    this.destroy();
            };

            MainUI.SetNick = function()
            {
                var nick = this.getChild("NickInput");
                var text = nick.getChild("n3").text;
                if (text.length > 0)
                {
                    var msg = {};
                    msg.RPC_ID = 0;
                    msg.strFunName = "SetNick";
                    msg.parm = [text];
                    console.log("Talk:");
                    console.log(msg);
                    this.Connect.Send_RunScript(msg,Laya.Handler.create(this,this.LoginResult));
                }
            };
            var setNickbutton = MainUI.getChild("NickButton");
            console.log(setNickbutton);
            setNickbutton.onClick(MainUI,MainUI.SetNick);
            MainUI.Talk = function()
            {
                var talk = this.getChild("TalkInput");
                var text = talk.getChild("n3").text;
                if (text.length > 0)
                {
                    var msg = {};
                    msg.RPC_ID = 0;
                    msg.strFunName = "Talk";
                    msg.parm = [text];
                    console.log("Talk:");
                    console.log(msg);
                    this.Connect.Send_RunScript(msg,Laya.Handler.create(this,this.LoginResult));
                }
            };
            var Talkbutton = MainUI.getChild("TalkButton");
            Talkbutton.onClick(MainUI,MainUI.Talk);
            console.log(this.dataList);
            MainUI._list = MainUI.getChild("n7").getChild("n1").asList;
            MainUI._list.itemRenderer = Laya.Handler.create(this, this.renderListItem, null, false);
            MainUI._list.numItems = this.dataList.length;
            MainUI._list.scrollToView(0);
            //MainUI._list.setVirtual();

            this.MainUI = MainUI;
            MainUI.getChild("NickInput").getChild("n3").text = this.MainAccount.GetAttribute("nickName");
        }
        LoginAccount()
        {
            var account = this.LoginUI.getChild("AccInput");
            var password  = this.LoginUI.getChild("PwInput");
            var msg = {};
            this.Connect.RpcIDAssign++;
            msg.RPC_ID = this.Connect.RpcIDAssign;
            msg.strFunName = "LoginAccount";
            msg.parm = [account.getChild("n3").text,password.getChild("n3").text];
            this.Connect.Send_RunScript(msg,Laya.Handler.create(this,this.LoginResult));
        }
        LoginResult(nResult)
        {
            console.log("LoginResult:"+nResult);
        }

        RegisterAccount()
        {

        }

        LoginFail(nResult)
        {
            console.log("LoginFail:"+nResult);
            if (nResult == 1)//账号不存在
            {
                this.OpenRegisterUI();
            }
        }
        LoginSuccess(pAccount)
        {
            this.dataList.push(pAccount.GetAttribute("nickName")+"登录成功");

            console.log("LoginSuccess:"+pAccount);
            this.MainAccount = pAccount;
            if (this.LoginUI)
            {
                this.LoginUI.OnClose();
                this.LoginUI = null;
            }

            this.OpenMainUI();
        }

        SendMessage(pAccount,strTalk)
        {
            console.log("SendMessage");
            this.dataList.push(pAccount.GetAttribute("nickName")+":"+strTalk);
            this.MainUI._list.numItems = this.dataList.length;
        }


        renderListItem(index, obj) {
            console.log("renderListItem:"+index);
            obj._mainUI = this;
            if (this.dataList.length > index)
            {
                obj.getChild("n0").text = this.dataList[index];
                console.log("renderListItem:"+this.dataList[index]);
            }
        }
    }

    /**This class is automatically generated by LayaAirIDE, please do not make any modifications. */

    class GameConfig {
        static init() {
            //注册Script或者Runtime引用
            let reg = Laya.ClassUtils.regClass;
    		reg("script/GameUI.js",GameUI);
        }
    }
    GameConfig.width = 1280;
    GameConfig.height = 720;
    GameConfig.scaleMode ="showall";
    GameConfig.screenMode = "horizontal";
    GameConfig.alignV = "middle";
    GameConfig.alignH = "center";
    GameConfig.startScene = "test/TestScene.scene";
    GameConfig.sceneRoot = "";
    GameConfig.debug = false;
    GameConfig.stat = false;
    GameConfig.physicsDebug = false;
    GameConfig.exportSceneToJson = true;

    GameConfig.init();

    class Main {
    	constructor() {
    		//根据IDE设置初始化引擎		
    		if (window["Laya3D"]) Laya3D.init(GameConfig.width, GameConfig.height);
    		else Laya.init(GameConfig.width, GameConfig.height, Laya["WebGL"]);
    		Laya["Physics"] && Laya["Physics"].enable();
    		Laya["DebugPanel"] && Laya["DebugPanel"].enable();
    		Laya.stage.scaleMode = GameConfig.scaleMode;
    		Laya.stage.screenMode = GameConfig.screenMode;
    		Laya.stage.alignV = GameConfig.alignV;
    		Laya.stage.alignH = GameConfig.alignH;
    		//兼容微信不支持加载scene后缀场景
    		Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;

    		//打开调试面板（通过IDE设置调试模式，或者url地址增加debug=true参数，均可打开调试面板）
    		if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true") Laya.enableDebugPanel();
    		if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"]) Laya["PhysicsDebugDraw"].enable();
    		if (GameConfig.stat) Laya.Stat.show();
    		Laya.alertGlobalError(true);

    		//激活资源版本控制，version.json由IDE发布功能自动生成，如果没有也不影响后续流程
    		Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION);
    	}

    	onVersionLoaded() {
    		//激活大小图映射，加载小图的时候，如果发现小图在大图合集里面，则优先加载大图合集，而不是小图
    		Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded));
    	}

    	onConfigLoaded() {
    		//加载IDE指定的场景
    		GameConfig.startScene && Laya.Scene.open(GameConfig.startScene);
    	}
    }
    //激活启动类
    new Main();

}());
